CREATE DATABASE  IF NOT EXISTS `prfinal` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `prfinal`;
-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: prfinal
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `direccion` varchar(50) DEFAULT NULL,
  `fecha_registro` date NOT NULL,
  PRIMARY KEY (`id_cliente`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datacpu`
--

DROP TABLE IF EXISTS `datacpu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datacpu` (
  `Nombre` text,
  `Precio` double DEFAULT NULL,
  `Proveedor` text,
  `MPN` text,
  `EAN` bigint DEFAULT NULL,
  `Reloj base` text,
  `Reloj turbo` text,
  `Multiplicador desbloqueado` text,
  `Nucleos` int DEFAULT NULL,
  `Subprocesos` int DEFAULT NULL,
  `TDP` text,
  `Socket` text,
  `GPU integrada` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datacpu`
--

LOCK TABLES `datacpu` WRITE;
/*!40000 ALTER TABLE `datacpu` DISABLE KEYS */;
/*!40000 ALTER TABLE `datacpu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datacpucooler`
--

DROP TABLE IF EXISTS `datacpucooler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datacpucooler` (
  `Nombre` text,
  `Precio` double DEFAULT NULL,
  `Proveedor` text,
  `MPN` text,
  `EAN` bigint DEFAULT NULL,
  `Enchufes compatibles` text,
  `Alto` text,
  `Soporte adicional para fan` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datacpucooler`
--

LOCK TABLES `datacpucooler` WRITE;
/*!40000 ALTER TABLE `datacpucooler` DISABLE KEYS */;
/*!40000 ALTER TABLE `datacpucooler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datagpu`
--

DROP TABLE IF EXISTS `datagpu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datagpu` (
  `Nombre` text,
  `Precio` double DEFAULT NULL,
  `Proveedor` text,
  `MPN` text,
  `EAN` bigint DEFAULT NULL,
  `Longitud` text,
  `Ranuras` double DEFAULT NULL,
  `Conectores de 8 pines` int DEFAULT NULL,
  `Conectores de 6 pines` int DEFAULT NULL,
  `HDMI` int DEFAULT NULL,
  `DisplayPort` int DEFAULT NULL,
  `DVI` int DEFAULT NULL,
  `VGA` int DEFAULT NULL,
  `Relog de Boost` text,
  `Vram` text,
  `Reloj de memoria` text,
  `TDP` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datagpu`
--

LOCK TABLES `datagpu` WRITE;
/*!40000 ALTER TABLE `datagpu` DISABLE KEYS */;
/*!40000 ALTER TABLE `datagpu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datahdd`
--

DROP TABLE IF EXISTS `datahdd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datahdd` (
  `Nombre` text,
  `Precio` double DEFAULT NULL,
  `Proveedor` text,
  `MPN` text,
  `EAN` bigint DEFAULT NULL,
  `TamaÃ±o` text,
  `RPM` double DEFAULT NULL,
  `Cache` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datahdd`
--

LOCK TABLES `datahdd` WRITE;
/*!40000 ALTER TABLE `datahdd` DISABLE KEYS */;
/*!40000 ALTER TABLE `datahdd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datamonitor`
--

DROP TABLE IF EXISTS `datamonitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datamonitor` (
  `ï»¿Nombre` text,
  `Precio` double DEFAULT NULL,
  `Proveedor` text,
  `MPN` text,
  `EAN` double DEFAULT NULL,
  `Resolucion` text,
  `Frecuencia de actualizacion` text,
  `TamaÃ±o` text,
  `Panel` text,
  `Tiempo de respuesta` int DEFAULT NULL,
  `HDMI` int DEFAULT NULL,
  `DisplayPort` int DEFAULT NULL,
  `DVI` int DEFAULT NULL,
  `VGA` int DEFAULT NULL,
  `Altavoz` text,
  `Curvado` text,
  `Altura ajustable` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datamonitor`
--

LOCK TABLES `datamonitor` WRITE;
/*!40000 ALTER TABLE `datamonitor` DISABLE KEYS */;
/*!40000 ALTER TABLE `datamonitor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datamotherboard`
--

DROP TABLE IF EXISTS `datamotherboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datamotherboard` (
  `Nombre` text,
  `Precio` double DEFAULT NULL,
  `Proveedor` text,
  `MPN` text,
  `EAN` bigint DEFAULT NULL,
  `Socket` text,
  `Chipset` text,
  `Desbloqueado` text,
  `Formato` text,
  `Desbloqueado_[0]` text,
  `Capacidad de memoria` text,
  `Ranuras de RAM` int DEFAULT NULL,
  `SATA` int DEFAULT NULL,
  `VGA` int DEFAULT NULL,
  `DVI` double DEFAULT NULL,
  `Puerto Display` double DEFAULT NULL,
  `HDMI` double DEFAULT NULL,
  `WiFi` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datamotherboard`
--

LOCK TABLES `datamotherboard` WRITE;
/*!40000 ALTER TABLE `datamotherboard` DISABLE KEYS */;
/*!40000 ALTER TABLE `datamotherboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datapsu`
--

DROP TABLE IF EXISTS `datapsu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datapsu` (
  `Nombre` text,
  `Precio` double DEFAULT NULL,
  `Proveedor` text,
  `MPN` text,
  `EAN` bigint DEFAULT NULL,
  `Watt` text,
  `TamaÃ±o` text,
  `CalificaciÃ³n de eficiencia` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datapsu`
--

LOCK TABLES `datapsu` WRITE;
/*!40000 ALTER TABLE `datapsu` DISABLE KEYS */;
/*!40000 ALTER TABLE `datapsu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataram`
--

DROP TABLE IF EXISTS `dataram`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dataram` (
  `Nombre` text,
  `Precio` double DEFAULT NULL,
  `Proveedor` text,
  `MPN` text,
  `EAN` bigint DEFAULT NULL,
  `Tipo de RAM` text,
  `TamaÃ±o` text,
  `Reloj` int DEFAULT NULL,
  `Tiempos` text,
  `Sticks` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataram`
--

LOCK TABLES `dataram` WRITE;
/*!40000 ALTER TABLE `dataram` DISABLE KEYS */;
/*!40000 ALTER TABLE `dataram` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datassd`
--

DROP TABLE IF EXISTS `datassd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datassd` (
  `ï»¿Nombre` text,
  `Precio` double DEFAULT NULL,
  `Proveedor` text,
  `MPN` text,
  `EAN` double DEFAULT NULL,
  `Formato` text,
  `Protocolo` text,
  `TamaÃ±o` text,
  `NAND` text,
  `Controlador` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datassd`
--

LOCK TABLES `datassd` WRITE;
/*!40000 ALTER TABLE `datassd` DISABLE KEYS */;
/*!40000 ALTER TABLE `datassd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datostorre`
--

DROP TABLE IF EXISTS `datostorre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datostorre` (
  `Nombre` text,
  `Precio` double DEFAULT NULL,
  `Proveedor` text,
  `MPN` text,
  `EAN` bigint DEFAULT NULL,
  `Ancho` text,
  `Profundidad` text,
  `Alto` text,
  `Placa Madre` text,
  `Abastecimiento de energia` text,
  `Longitud de GPU admitida` text,
  `Altura CPU refrigerador admitida` text,
  `80mm Fans` text,
  `120mm Fans` text,
  `140mm Fans` text,
  `200mm Fans` text,
  `Disk 2.5"` int DEFAULT NULL,
  `Disk 3.5"` int DEFAULT NULL,
  `Color Primario` text,
  `Filtro de polvo` text,
  `Gestion de cable` text,
  `Aislamiento de ruido` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datostorre`
--

LOCK TABLES `datostorre` WRITE;
/*!40000 ALTER TABLE `datostorre` DISABLE KEYS */;
/*!40000 ALTER TABLE `datostorre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contrasena` varchar(20) NOT NULL,
  `fecha_creacion` date NOT NULL,
  `rol` varchar(50) NOT NULL,
  `estado` varchar(20) NOT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `nombre_usuario` (`nombre_usuario`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventas`
--

DROP TABLE IF EXISTS `ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventas` (
  `id_venta` int NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `total` decimal(5,2) NOT NULL,
  `metodo_pago` varchar(25) NOT NULL,
  PRIMARY KEY (`id_venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventas`
--

LOCK TABLES `ventas` WRITE;
/*!40000 ALTER TABLE `ventas` DISABLE KEYS */;
/*!40000 ALTER TABLE `ventas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-03 16:05:21
